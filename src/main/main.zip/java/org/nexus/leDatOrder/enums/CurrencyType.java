package org.nexus.leDatOrder.enums;

public enum CurrencyType {
    VAULT,
    PLAYERPOINTS
}